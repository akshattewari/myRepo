import React, { useState, useEffect } from "react";

const GenAI = () => {
  const [message, setMessage] = useState("");

  useEffect(() => {
    const fetchDataFromAPI = async () => {
      const api = await fetch("http://127.0.0.1:5000/genaix");
      const data = await api.json();

      setMessage(data.message);
      console.log("My Data = ", data);
    };

    fetchDataFromAPI();
  }, []);

  return (
    <div>
      <h1>{message || "Loading..."}</h1>
    </div>
  );
};

export default GenAI;
