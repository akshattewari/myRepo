import Movies from "./MovieZone/Movies";
import UseEffect from "./components/UseEffect";
import Fetch_Data_API from "./components/Fetch_Data_API";
import TestCopilot from "./components/TestCopilot";
import Forms from "./components/Forms";
import Gemini from "./components/Gemini";
import FilterProduct from "./components/FilterProduct";
import TestRouter from "./TestRouter";

const App = () => {
  return (
    <>
      {/* <Movies /> */}
      {/* <TestCopilot /> */}
      {/* <UseEffect /> */}
      {/* <Fetch_Data_API /> */}
      {/* <Forms /> */}
      {/* <Gemini /> */}

      {/* <FilterProduct /> */}
      <TestRouter />

    </>
  );
};

export default App;
