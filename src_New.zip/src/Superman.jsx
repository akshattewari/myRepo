import React from 'react'

const Superman = () => {
  return (
    <div>
      <h1>Superman </h1>
    </div>
  )
}

export default Superman
