import React from 'react'
import Superman from './Superman';

const Person = () => {
  const name = "Akshat";
  const age = 30;

  const person = {
    name:'Akshat',
    age:30,
  };
  const product = {
    title:"iPhone",
    model:16,
  };  
  
    return (
    <>
        <div>
        {/* <h1>Good Morning {name}</h1>
        <p>Age = {age}</p>
        <h1>{2*4}</h1> */}
            <h1>Name = {person.name}</h1>  
        </div>
    <Superman />
        <div>
            <h3>Product = {product.title}</h3>
            <h3>Model = {product.model}</h3>
        </div>
    
    </>
  );
}

export default Person
