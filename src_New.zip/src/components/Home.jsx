import React from "react";
import Person from "./Person";
import Casual from "./components/Test";
import Product from "./components/Product";
import Person2 from "./components/Person2";
import Person3 from "./components/Person3";
import Laptop from "./components/Laptop";
import Events from "./components/Events";
import Counter from "./components/Counter";
import Showproduct from "./components/Showproduct";
import FilterProduct from "./components/FilterProduct";

const Home = () => {
  return (
    <>
{/* <div>
        <h3>
          <Laptop brand="HP" model="probook" price={150000} />
        </h3>
        <h3>
          <Laptop brand="Lenovo" model="yoga" price={120000} />
        </h3>
        <h3>
          <Laptop brand="Dell" model="Inspiron" price={150000} />
        </h3>
      </div>

      <div>
        <Person />
        <Casual />
        <Product title="Galaxy S24 Ultra" brand="Samsung" price={150000} />
        <Product title="iPhone 16" brand="Apple" price={175000} />

        <Person2 name="Akshat" age="25" salary={500000} />
        <Person2 name="Superman" age="125" salary={2500000} />
        <Person2 name="Spiderman" age="250" salary={5044500} ram="RAM" />
      </div>

      <div>
        <Person3 name="Superman" age={18} pancard={true} />
      </div> */}

      {/* <div>
        <Events />
      </div> */}
      <div>
      
      <Showproduct />
      <FilterProduct />  
       </div>
    


    </>
  )
}

export default Home
