import React from 'react'

const FilterProduct = () => {
  const products = [
{id:1,title:"iphone 16", category:"mobiles",price:125000},
{id:2,title:"Notebook pro", category:"Laptop",price:105000},
{id:3,title:"Mi Tab", category:"tablet",price:165000},
{id:4,title:"Sony Camera", category:"camera",price:225000},
  ];

  const filteredData = products.filter((datax) => datax.category == 'tablet');
  console.log(filteredData);
  
  return (
    <div>
        {filteredData.map((datax)=><div key={datax.id}>
        <h1>{datax.title}</h1>
        <p>{datax.price}</p>    
    </div>)
    
    }
    </div>
  )
}

export default FilterProduct
