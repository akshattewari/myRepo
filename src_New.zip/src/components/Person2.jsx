import React from 'react'

const Person2 = ({name,age,salary}) => {
  return (
    <div>
        <h2>Person2 Name = {name}</h2>
        <h3>Person2 Age = {age}</h3>
        <h4>Person2 Salary = {salary}</h4>
    </div>
  )
}

export default Person2
