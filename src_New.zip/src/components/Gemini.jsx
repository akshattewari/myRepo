import React from 'react'
import { GoogleGenAI } from "@google/genai";

const Gemini = async () => {

    const ai = new GoogleGenAI({apiKey: "AIzaSyAuk6CKjrvTpPWCWi8a8YXk62illkw32Y0"});
async function main() {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: "Explain how AI works in a few words",
  });
  console.log(response.text);
}

await main();

    return (
    <div>

    </div>
  )
}


export default Gemini
