import React from "react";

const Person3 = ({ name, age, pancard }) => {
  return (
    <div>
      <h2>Name = {name}</h2>
      <h3> {age > 18 ? <h1>You can drive</h1> : <h1>You cannot drive</h1>} </h3>
      <h3> {pancard == true ? <h1>Eligible for bank</h1> : ""} </h3>
      <h2>{pancard && <p>Eligible for bank</p>}</h2>  
    </div>
  );
};

export default Person3;
