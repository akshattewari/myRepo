import React from "react";
import { BrowserRouter, Routes, Route, NavLink } from "react-router-dom";
import Fetch_Data_API from "./components/Fetch_Data_API";
import Home from "./Pages/Home";
import About from "./Pages/About";
import Products from "./Pages/Products";
import GenAI from "./Pages/GenAI";
import { Button } from "@mui/material";

const TestRouter = () => {
  return (
    <>
      <h1>This is router page</h1>
      

      <BrowserRouter>
      <NavLink to="/"><Button>Home</Button></NavLink>
      <NavLink to="/about"><Button>About</Button></NavLink>
      <NavLink to="/products"><Button>Products</Button></NavLink>
      <NavLink to="/genai"><Button>GenAI</Button></NavLink>
      <NavLink to="/fetch-data"><Button>Fetch Data</Button></NavLink>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/products" element={<Products />} />
          <Route path="/genai" element={<GenAI />} />
          <Route path="/fetch-data" element={<Fetch_Data_API />} />
        </Routes>
      </BrowserRouter>
    </>
  );
};

export default TestRouter;
