import React from "react";

const Showproduct = () => {
  let products = [
    { id: 1, title: "iphone16", price: 175000 },
    { id: 2, title: "iphone15", price: 165000 },
    { id: 3, title: "iphone14", price: 155000 },
    { id: 4, title: "iphone13", price: 145000 },
  ];

  return (
    <div>
      {products.map((data) => (
        <div key={data.id}>
          <h1>Title = {data.title}</h1>
          <h2>Price = {data.price}</h2>
        </div>
      ))}
    </div>
  );
};

export default Showproduct;
