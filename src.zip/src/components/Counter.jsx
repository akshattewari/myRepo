import React, { useState } from "react";

const Counter = () => {
  //let counter = 0;
  
  const[counter,setCounter] = useState(0)
  const[obj,setobj] = useState(
    {
        name:'Akshat',
        salary:150000,
        age:24,

    }
  )  

  const increaseBy1 = () => {
    setCounter(counter+1)
    //counter++;
    //console.log("Counter = ", counter);
  };

  const decreaseBy1 = () => {
    setCounter(counter-1)
    counter--;
    console.log("Counter =", counter);
  };

  return (
    <div>
      <h1>{counter}</h1>
      <button onClick={increaseBy1}>Increase</button>
      <button onClick={decreaseBy1}>Decrease</button>
      <h2>{obj.name}</h2>
    </div>
  );
};

export default Counter;
