import React, { useState } from 'react'
import './Forms.css'

const Forms = () => {
  const [name, setname] = useState('Sample name')
  const [email, setemail] = useState('')
  const [password, setpassword] = useState('')

  return (
    <>
      <div className="form-container">
        <form action="">
          <div>
            Name: <input type="text" value={name} onChange={(e) => setname(e.target.value)} name="name" />
          </div>
          <div>
            Email: <input type="email" value={email} onChange={(e) => setemail(e.target.value)} name="email" />
          </div>
          <div>
            Password: <input type="password" value={password} onChange={(e) => setpassword(e.target.value)} name="password" />
          </div>
          <div>
            <button type="submit">Submit</button>
          </div>
        </form>
      </div>
    </>
  )
}

export default Forms
