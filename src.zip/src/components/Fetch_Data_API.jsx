import React, { useEffect, useState } from "react";

const Fetch_Data_API = () => {
  const [apiData, setapiData] = useState([]);

  useEffect(() => {
    const fetchDataFromAPI = async () => {
      const api = await fetch("https://jsonplaceholder.typicode.com/todos");
      const data = await api.json();

      setapiData(data);
      console.log("My Data = ", data);
    };

    fetchDataFromAPI();
  }, []);

  return (
    <div>
      {" "}
      {apiData.map((data) => (
        <div key={data.id}>
          <h3>{data.title}</h3>
        </div>
      ))}
    </div>
  );
};

export default Fetch_Data_API;
