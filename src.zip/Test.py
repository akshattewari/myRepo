from flask import Flask, jsonify
from flask_cors import CORS
from google import genai


app = Flask(__name__)
CORS(app)

@app.route("/about", methods=["GET"])
def about():
    return jsonify(message="About Page from Python")

@app.route("/home", methods=["GET"])
def home():
    return jsonify(message="Home Page from Python")

@app.route("/products", methods=["GET"])
def products():
    return jsonify(message="Products Page from Python")


@app.route("/genaix", methods=["GET"])
def genaix():
     client = genai.Client(api_key="AIzaSyAuk6CKjrvTpPWCWi8a8YXk62illkw32Y0")
     response = client.models.generate_content(
         model="gemini-2.5-flash", contents="Explain how AI works in a few words"
     )
     return jsonify(message = response.text)


if __name__ == "__main__":
    app.run(port=5000)   # Runs on http://localhost:5000
